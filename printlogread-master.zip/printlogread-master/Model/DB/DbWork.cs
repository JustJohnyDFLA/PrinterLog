﻿using System;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Windows;

namespace PrintLogRead.Model.DB
{
    public class DbWork
    {
        /// <summary>
        /// Получить статистику (100 000 записей) без учета дат
        /// </summary>
        public string StatStart { get; private set; } = "SELECT TOP(5000) id, timecreated as t, FORMAT(timecreated, 'dd.MM.yyyy HH:mm:ss') as timecreated2, userlog, compdomen, printer, countpages, messagelog, departament FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2] ORDER by t desc";
        /// <summary>
        /// Получить статистику с учетом периода 
        /// </summary>
        public string StatDate { get; private set; } = "SELECT  id, timecreated as t, FORMAT(timecreated, 'dd.MM.yy HH:mm:ss') as timecreated2, userlog, compdomen, printer, countpages, messagelog, departament FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2] WHERE timecreated>=CONVERT(datetime, @startDate, 103) AND timecreated<=CONVERT(datetime, @endDate, 103)";

        /// <summary>
        /// Получить всю статистику за все время
        /// </summary>
        public string StatAll { get; private set; } = "SELECT timecreated as t,  id, FORMAT(timecreated, 'dd.MM.yy HH:mm:ss') as timecreated2, userlog, compdomen, printer, countpages, messagelog, departament FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2] ORDER by t desc";

        /// <summary>
        /// Статистика с учетом групировки по принтеру и департаменту
        /// </summary>
        public string GropDep { get; private set; } = "SELECT printer, departament, sum(countpages) as cntpgs FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2]";// GROUP BY printer, userlog ORDER BY printer, userlog";
        public string GropUser { get; private set; } = "SELECT printer, userlog, sum(countpages) as cntpgs FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2]";// GROUP BY printer, userlog ORDER BY cntpgs desc, userlog, printer";
        public string GetGropDepUser { get; private set; } = "SELECT printer, userlog, departament, sum(countpages) as cntpgs FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2]";// GROUP BY printer, userlog ORDER BY cntpgs desc, userlog, printer";
        public string PrntAdditionally { get; private set; } = "SELECT printer, sum(countpages) as cntpgs FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2]";// GROUP BY printer, userlog ORDER BY cntpgs desc, userlog, printer";
        public string DepAdditionally { get; private set; } = "SELECT departament, sum(countpages) as cntpgs FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2]";// GROUP BY printer, userlog ORDER BY cntpgs desc, userlog, printer";
        public string UserAdditionally { get; private set; } = "SELECT userlog, sum(countpages) as cntpgs FROM [BK_SSK_PRINTLOG].[dbo].[Prlog2]";// GROUP BY printer, userlog ORDER BY cntpgs desc, userlog, printer";

        /* public DbWork(SqlConnection conn)
         {
           // this.sqlcmd = new SqlCommand();
           // this.sqlcmd.Connection = conn;
         }*/
        /// <summary>
        /// Получить статистку
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        internal ObservableCollection<PrLog> StartApp(string query)
        {
            ObservableCollection<PrLog> lPrLog = new ObservableCollection<PrLog>();
            try
            {
                Db db = new Db();
                using (SqlConnection conn = new SqlConnection(db.connectionString))
                {
                    conn.Open();
                    SqlCommand sqlcmd = new SqlCommand();
                    sqlcmd.Connection = conn;
                    sqlcmd.CommandText = query;
                    SqlDataReader reader = sqlcmd.ExecuteReader();
                    while (reader.Read())
                    {
                        PrLog prLog = new PrLog();
                        //prLog.RowNm = (long)reader["RowNm"];
                        prLog.Id = (long)reader["id"];
                        prLog.Userlog = reader["userlog"].ToString();
                        prLog.Compdomen = reader["compdomen"].ToString();
                        prLog.Printer = reader["printer"].ToString();
                        prLog.Countpages = (int)reader["countpages"];
                        prLog.Messagelog = reader["messagelog"].ToString();
                        prLog.Departement = reader["departament"].ToString();
                        prLog.Timecreated2 = DateTime.Parse(reader["timecreated2"].ToString()); ;
                        lPrLog.Add(prLog);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return lPrLog;
        }

        internal ObservableCollection<PrLog> GetStaticDate(string query, string startDate, string endDate)
        {
            ObservableCollection<PrLog> lPrLog = new ObservableCollection<PrLog>();
            try
            {
                Db db = new Db();
                using (SqlConnection conn = new SqlConnection(db.connectionString))
                {
                    conn.Open();
                    SqlCommand sqlcmd = new SqlCommand();
                    sqlcmd.Connection = conn;

                    sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                    sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    sqlcmd.CommandText = query;
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        PrLog prLog = new PrLog();
                        //prLog.RowNm = (long)reader["RowNm"];
                        prLog.Id = (long)reader["id"];
                        prLog.Userlog = reader["userlog"].ToString();
                        prLog.Compdomen = reader["compdomen"].ToString();
                        prLog.Printer = reader["printer"].ToString();
                        prLog.Countpages = (int)reader["countpages"];
                        prLog.Messagelog = reader["messagelog"].ToString();
                        prLog.Departement = reader["departament"].ToString();
                        prLog.Timecreated2 = DateTime.Parse(reader["timecreated2"].ToString());
                        lPrLog.Add(prLog);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return lPrLog;
        }

        /// <summary>
        /// Получить статистику по принтеру и подразделению
        /// </summary>
        /// <param name="query"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>      
        internal ObservableCollection<PrLog> GetGroupDep(string query, string startDate, string endDate)
        {
            ObservableCollection<PrLog> lPrLogDep = new ObservableCollection<PrLog>();
            try
            {
                Db db = new Db();
                using (SqlConnection conn = new SqlConnection(db.connectionString))
                {
                    conn.Open();
                    SqlCommand sqlcmd = new SqlCommand();
                    sqlcmd.Connection = conn;
                    if (!string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103) AND timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }
                    else if (!string.IsNullOrEmpty(startDate) && string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                    }
                    else if (string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }

                    query += " GROUP BY printer, departament ORDER BY cntpgs desc, departament, printer";

                    sqlcmd.CommandText = query;
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        PrLog prLogGroupDep = new PrLog();
                        prLogGroupDep.printer = reader["printer"].ToString();
                        prLogGroupDep.Countpages = (int)reader["cntpgs"];
                        prLogGroupDep.Departement = reader["departament"].ToString();
                        lPrLogDep.Add(prLogGroupDep);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return lPrLogDep;
        }



        /// <summary>
        /// Получить статистику с по принтеру и сотруднику
        /// </summary>
        /// <param name="query"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        internal ObservableCollection<PrLog> GetGroupUser(string query, string startDate, string endDate)
        {
            ObservableCollection<PrLog> lPrLogDep = new ObservableCollection<PrLog>();
            try
            {
                Db db = new Db();
                using (SqlConnection conn = new SqlConnection(db.connectionString))
                {
                    conn.Open();
                    SqlCommand sqlcmd = new SqlCommand();
                    sqlcmd.Connection = conn;
                    if (!string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103) AND timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }
                    else if (!string.IsNullOrEmpty(startDate) && string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                    }
                    else if (string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }

                    query += " GROUP BY printer, userlog ORDER BY cntpgs desc, userlog, printer";

                    sqlcmd.CommandText = query;
                    SqlDataReader reader = sqlcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        PrLog prLogGroupDep = new PrLog();
                        prLogGroupDep.printer = reader["printer"].ToString();
                        prLogGroupDep.Countpages = (int)reader["cntpgs"];
                        prLogGroupDep.Userlog = reader["userlog"].ToString();
                        lPrLogDep.Add(prLogGroupDep);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return lPrLogDep;
        }


        /// <summary>
        /// Статистика с группировкой по департаменту и пользователю
        /// </summary>
        /// <param name="query"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        internal ObservableCollection<PrLog> GetGroupDepUser(string query, string startDate, string endDate)
        {
            ObservableCollection<PrLog> lPrLogDep = new ObservableCollection<PrLog>();
            try
            {
                Db db = new Db();
                using (SqlConnection conn = new SqlConnection(db.connectionString))
                {
                    conn.Open();
                    SqlCommand sqlcmd = new SqlCommand();
                    sqlcmd.Connection = conn;
                    if (!string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103) AND timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }
                    else if (!string.IsNullOrEmpty(startDate) && string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                    }
                    else if (string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }

                    query += " GROUP BY printer, userlog, departament ORDER BY cntpgs desc, departament, userlog, printer";
                    sqlcmd.CommandText = query;
                    SqlDataReader reader = sqlcmd.ExecuteReader();
                    while (reader.Read())
                    {
                        PrLog prLogGroupDep = new PrLog();
                        prLogGroupDep.Departement = reader["departament"].ToString();
                        prLogGroupDep.Printer = reader["printer"].ToString();
                        prLogGroupDep.Countpages = (int)reader["cntpgs"];
                        prLogGroupDep.Userlog = reader["userlog"].ToString();
                        lPrLogDep.Add(prLogGroupDep);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return lPrLogDep;
        }



        internal ObservableCollection<PrLog> GetGroupAdditionally(string query, string startDate, string endDate, int mode)
        {
            ObservableCollection<PrLog> lPrLogDep = new ObservableCollection<PrLog>();
            try
            {
                Db db = new Db();
                using (SqlConnection conn = new SqlConnection(db.connectionString))
                {
                    conn.Open();
                    SqlCommand sqlcmd = new SqlCommand();
                    sqlcmd.Connection = conn;
                    if (!string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103) AND timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }
                    else if (!string.IsNullOrEmpty(startDate) && string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated>=CONVERT(datetime, @startDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@startDate", startDate);
                    }
                    else if (string.IsNullOrEmpty(startDate) && !string.IsNullOrEmpty(endDate))
                    {
                        query += " WHERE timecreated<=CONVERT(datetime, @endDate, 103)";
                        sqlcmd.Parameters.AddWithValue("@endDate", endDate);
                    }

                    if(mode==4) query += " GROUP BY printer ORDER BY cntpgs desc";
                    if(mode==5) query += " GROUP BY departament ORDER BY cntpgs desc";
                    if(mode==6) query += " GROUP BY userlog ORDER BY cntpgs desc";

                    sqlcmd.CommandText = query;
                    SqlDataReader reader = sqlcmd.ExecuteReader();
                    while (reader.Read())
                    {
                        PrLog prLogGroupDep = new PrLog();
                        if (mode == 4)
                        {
                            prLogGroupDep.Printer = reader["printer"].ToString();
                        }
                        if (mode == 5)
                        {
                            prLogGroupDep.Departement = reader["departament"].ToString();
                        }
                        if(mode == 6)
                        {
                            prLogGroupDep.Userlog = reader["userlog"].ToString();
                        }
                        prLogGroupDep.Countpages = (int)reader["cntpgs"];
                        lPrLogDep.Add(prLogGroupDep);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return lPrLogDep;
        }
    }
}
