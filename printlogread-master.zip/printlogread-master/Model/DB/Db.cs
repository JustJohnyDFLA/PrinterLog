﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintLogRead.Model.DB
{
    public class Db
    {
        #region old variant singleton
        //static Db() { }
        //private Db() { }

        // private static readonly Db objDb = new Db();

        //private string connectionString = "Data Source=(bk-ssk-sqldn03); Initial Catalog=bk_ssk_printlog; Integrated Security=True; providerName='System.Data.SqlClient'";

        //static SqlConnection con = new SqlConnection("Data Source=bk-ssk-sqldn03; Initial Catalog=bk_ssk_printlog; Integrated Security=SSPI");//providerName='System.Data.SqlClient'


        /* public static Db ObjDb
         {
             get { return objDb; }
         }

         public static SqlConnection ConGetDbConnection()
         {
             return con;
         }*/
        #endregion
        
       //public string connectionString { get;  set; } = "Data Source=bk-ssk-sqldn03; Initial Catalog=bk_ssk_printlog; Integrated Security=SSPI";
       public string connectionString { get;  set; } = "Data Source=bk-ssk-sqlf01; Initial Catalog=bk_ssk_printlog; Integrated Security=SSPI";
        /*public Db()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
            }

        }*/
    }
}
