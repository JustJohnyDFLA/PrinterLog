﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PrintLogRead.Model
{
    internal class PrLog : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }

        //public long rowNm;
        public long id;
        public int eventId;
        public DateTime timecreated2;
        public string userlog;
        public string compdomen;
        public string printer;
        public int countpages;
        public string messagelog;
        public string departement;


      /*  public long RowNm
        {
            get { return rowNm; }
            set
            {
                rowNm = value;
                OnPropertyChanged();
            }
        }
*/

        public long Id {
            get { return id; }
            set
            {
                id = value;
                OnPropertyChanged();
            }

        }
        public int EventId 
        {
            get { return eventId; }
            set
            {
                eventId = value;
                OnPropertyChanged();
            }


        }
        public DateTime Timecreated2
        {
            get { return timecreated2; }
            set
            {
                timecreated2 = value;
                OnPropertyChanged();
            }

        }
        public string Userlog 
        {
            get { return userlog; }
            set
            {
                userlog = value;
                OnPropertyChanged();
            }

        }
        public string Compdomen 
        {
            get { return compdomen; }
            set
            {
                compdomen = value;
                OnPropertyChanged();
            }

        }
        public string Printer
        {
            get { return printer; }
            set
            {
                printer = value;
                OnPropertyChanged();
            }

        }
        public int Countpages 
        {
            get { return countpages; }
            set
            {
                countpages = value;
                OnPropertyChanged();
            }

        }
        public string Messagelog 
        {
            get { return messagelog; }
            set
            {
                messagelog = value;
                OnPropertyChanged();
            }

        }
        public string Departement
        {
            get { return departement; }
            set
            {
                departement = value;
                OnPropertyChanged();
            }

        }
    }
}
