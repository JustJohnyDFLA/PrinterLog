﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PrintLogRead.Model
{
    internal class PrLogGroupDep : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }


        public string printer;
        public int countpages;
        public string departement;


        public string Printer
        {
            get { return printer; }
            set
            {
                printer = value;
                OnPropertyChanged();
            }

        }
        public int Countpages
        {
            get { return countpages; }
            set
            {
                countpages = value;
                OnPropertyChanged();
            }

        }
        public string Departement
        {
            get { return departement; }
            set
            {
                departement = value;
                OnPropertyChanged();
            }

        }
    }
}
