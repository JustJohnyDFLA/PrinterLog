﻿using PrintLogRead.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using PrintLogRead.Model.DB;
using System.Data;
using System.Windows.Data;
using System.Windows;

namespace PrintLogRead.ViewModel
{
    internal class PrintLogReadViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<PrLog> PrLogMV { get; set; } = new ObservableCollection<PrLog>();

        /// <summary>
        /// Получить статистику с учетом режима отображения 0 - стартовый режим (100 000), 1 - все данные
        /// </summary>
        /// <param name="mode">режим отображения</param>
        string sql = "";
        public void GetStatictic(int mode)
        {
            try
            {
                DbWork dbWork = new DbWork();
                if (mode == 0) sql = dbWork.StatStart;
                else sql = dbWork.StatAll;
                PrLogMV = dbWork.StartApp(sql);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void GetStaticticGroup(string start, string end)
        {
            try
            {
                string sql = "";
                DbWork dbWork = new DbWork();
                sql = dbWork.GropDep;
                PrLogMV = dbWork.GetGroupDep(sql, start, end);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void GetStaticticGroupUser(string start, string end)
        {
            try
            {
                DbWork dbWork = new DbWork();
                sql = dbWork.GropUser;
                PrLogMV = dbWork.GetGroupUser(sql, start, end);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public void GetStaticticGroupUserDep(string start, string end)
        {
            try
            {
                DbWork dbWork = new DbWork();
                sql = dbWork.GetGropDepUser;
                PrLogMV = dbWork.GetGroupDepUser(sql, start, end);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Получить дополнительную статистику
        /// </summary>
        /// <param name="start">дата начало периода</param>
        /// <param name="end">дата конец периода</param>
        /// <param name="mode">режим 4-принтер кол., 5-подраз кол. 6-пользов кол.</param>
        public void GetStatictAdditionally(string start, string end, int mode)
        {
            try
            {
                DbWork dbWork = new DbWork();
                sql = "";
                if(mode == 4) sql = dbWork.PrntAdditionally;
                if(mode == 5) sql = dbWork.DepAdditionally;
                if(mode == 6) sql = dbWork.UserAdditionally;
                PrLogMV = dbWork.GetGroupAdditionally(sql, start, end, mode);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /// <summary>
        /// Статистика с учетом начала и конца периода
        /// </summary>
        /// <param name="start">Начальная дата</param>
        /// <param name="end">Конечная дата</param>
        public void GetStaticticDate(string start, string end)
        {
            try
            { 
                DbWork dbWork = new DbWork();
                PrLogMV = dbWork.GetStaticDate(dbWork.StatDate, start, end);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
             PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }

        protected void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
