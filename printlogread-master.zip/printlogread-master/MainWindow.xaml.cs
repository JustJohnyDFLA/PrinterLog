﻿using ClosedXML.Excel;
using Microsoft.Win32;
using PrintLogRead.Model;
using PrintLogRead.Model.DB;
using PrintLogRead.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PrintLogRead
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ICollectionView ItemsView;
        string Search = "";
        public bool Flag { get; set; } = true;
        /// <summary>
        /// Режим сортировки 0 - для начальной страницы, 1 - группировка по принтеру, и подразделению, 2 -  принтеру, и сотруднику, 3 - группировкой по принтеру, подразделению и сотруднику
        /// </summary>
        public static byte mode { get; set; } = 0;
        delegate string SumColm(DataGrid d);
        private SumColm Sum = (DataGrid dtg) => dtg.Items.OfType<PrLog>().Sum(i => i.Countpages).ToString();

        delegate string CountDep(DataGrid dtg);
        private CountDep CntDp => (DataGrid dtg) => dtg_printlog.Items.OfType<PrLog>().Select(o => o.Departement).Distinct().ToList().Count().ToString();

        delegate string CountPrn(DataGrid dtg);
        private CountDep CntPrn => (DataGrid dtg) => dtg_printlog.Items.OfType<PrLog>().Select(o => o.Printer).Distinct().ToList().Count().ToString();  
        delegate string CountUsr(DataGrid dtg);
        private CountUsr CntUsr => (DataGrid dtg) => dtg_printlog.Items.OfType<PrLog>().Select(o => o.Userlog).Distinct().ToList().Count().ToString();

        //CntDomName
        delegate string CountntDomenName(DataGrid dtg);
        private CountntDomenName CntDomName => (DataGrid dtg) => dtg_printlog.Items.OfType<PrLog>().Select(o => o.Compdomen).Distinct().ToList().Count().ToString();
        public MainWindow()
        {
            InitializeComponent();
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                #region старый вариант
                /* PrintLogReadViewModel prLogVM = new PrintLogReadViewModel();
                 prLogVM.GetStatictic(0);
                 ItemsView = CollectionViewSource.GetDefaultView(prLogVM.PrLogMV);
                 ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                 this.dtg_printlog.ItemsSource = ItemsView;
                 DisplayStatistics();*/

                /* Dispatcher.BeginInvoke(new Action(() =>
                 {
                     Window window = new Window();
                     window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                     window.Width = 150;
                     window.Height = 75;
                     window.Content = new ProgressBar()
                     {
                         Minimum = 0,
                         Maximum = 100,
                         IsIndeterminate = true
                     };
                     window.Show();
                     MainWn.Opacity = 0;
                 }));*/
                #endregion
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }
        /// <summary>
        /// Цвет 1  для строк
        /// </summary>
        //private SolidColorBrush gr = new SolidColorBrush(Colors.LightGray);
        
        /// <summary>
        /// Wdtn2 для строк
        /// </summary>
        //private SolidColorBrush wt = new SolidColorBrush(Colors.WhiteSmoke);

        /// <summary>
        /// Обработка загрузки строк (используеться для отображения номера строки)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Header = (e.Row.GetIndex() + 1).ToString();
        }

        /// <summary>
        /// Функция фильтр для ICollectionView
        /// </summary>
        /// <param name="prlog"></param>
        /// <param name="Search"></param>
        /// <returns></returns>
        internal bool Filter(PrLog prlog, string Search, int mode)
        {
            char[] sep = new char[] { '#' };
            string[] sEah = Search.Split(sep);
            if (mode == 0) 
            {
                if (sEah.Length == 2)
                {
                    return Search == null || (prlog.Printer.IndexOf(sEah[0], StringComparison.OrdinalIgnoreCase) != -1
                                      && prlog.Departement.IndexOf(sEah[1], StringComparison.OrdinalIgnoreCase) != -1);
                }
                else if (sEah.Length == 3)
                {
                    return Search == null ||
                                    (prlog.Printer.IndexOf(sEah[0], StringComparison.OrdinalIgnoreCase) != -1
                                     && prlog.Departement.IndexOf(sEah[1], StringComparison.OrdinalIgnoreCase) != -1
                                     && prlog.Userlog.IndexOf(sEah[2], StringComparison.OrdinalIgnoreCase) != -1);
                }
                else if (sEah.Length == 4)
                {
                    return Search == null ||
                                    (prlog.Printer.IndexOf(sEah[0], StringComparison.OrdinalIgnoreCase) != -1
                                     && prlog.Departement.IndexOf(sEah[1], StringComparison.OrdinalIgnoreCase) != -1
                                     && prlog.Userlog.IndexOf(sEah[2], StringComparison.OrdinalIgnoreCase) != -1
                                     && prlog.Compdomen.IndexOf(sEah[3], StringComparison.OrdinalIgnoreCase) != -1
                                     );
                }
                else
                {
                    return Search == null
                        || prlog.Printer.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1
                        || prlog.Departement.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1
                        || prlog.Compdomen.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1
                        || prlog.Userlog.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1;
                }
            }
            else if (mode == 1)
            {
                if (sEah.Length == 2)
                {
                    return Search == null ||(prlog.Printer.IndexOf(sEah[0], StringComparison.OrdinalIgnoreCase) != -1
                                     && prlog.Departement.IndexOf(sEah[1], StringComparison.OrdinalIgnoreCase) != -1);
                }
                else
                {
                    return Search == null
                                     || (prlog.Printer.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1
                                     || prlog.Departement.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1);
                }
               
            }
            else if (mode == 2)
            {
                if(sEah.Length == 2)
                {
                    return Search == null
                                || (prlog.Printer.IndexOf(sEah[0], StringComparison.OrdinalIgnoreCase) != -1
                                && prlog.Userlog.IndexOf(sEah[1], StringComparison.OrdinalIgnoreCase) != -1);
                }
                else
                {
                    return Search == null
                                || (prlog.Printer.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1
                                || prlog.Userlog.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1);
                }
                
            }
            else if (mode == 3)
            {
                if (sEah.Length == 2)
                {
                    return Search == null
                                || (prlog.Printer.IndexOf(sEah[0], StringComparison.OrdinalIgnoreCase) != -1
                                && prlog.Userlog.IndexOf(sEah[1], StringComparison.OrdinalIgnoreCase) != -1
                                );
                } else if (sEah.Length == 3)
                {
                    return Search == null
                                || (prlog.Printer.IndexOf(sEah[0], StringComparison.OrdinalIgnoreCase) != -1
                                && prlog.Userlog.IndexOf(sEah[1], StringComparison.OrdinalIgnoreCase) != -1
                                && prlog.Departement.IndexOf(sEah[2], StringComparison.OrdinalIgnoreCase) != -1);
                }
                else
                {
                    return Search == null
                                || (prlog.Printer.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1
                                || prlog.Userlog.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1
                                || prlog.Departement.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1);
                }
                
            }
            else if (mode == 4)
            {
                return Search == null
                               || (prlog.Printer.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1);
            }
            else if (mode == 5)
            {
                return Search == null
                               || (prlog.Departement.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1);
            }
            else if (mode == 6)
            {
                return Search == null
                               || (prlog.Userlog.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1);
            }
            else
            {
                return Search == null
                        || prlog.Printer.IndexOf(Search, StringComparison.OrdinalIgnoreCase) != -1;
            }


            
        }

        private void txtFiltr_textChanged(object sender, TextChangedEventArgs e)
        {
            Search = txtFiltr.Text;
            ItemsView.Refresh();
            DisplayStatistics();
        }

        private void Click_btnReset(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtFiltr.Text)) return;
            txtFiltr.Text = "";
            ItemsView.Refresh();
        }
        /// <summary>
        /// Обработка кнопки поиск с учетом дат
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Click_btnSearch(object sender, RoutedEventArgs e)
        {
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                if (mode == 0 && string.IsNullOrEmpty(startDatePicker.Text) || string.IsNullOrEmpty(endDatePicker.Text))
                {
                    MessageBox.Show("Необходимо заполнить  поля \"Выбор даты\" !", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                if ( mode == 0 && startDatePicker.Text == endDatePicker.Text)
                {
                    MessageBox.Show("Поля \"Выбор даты\" не могут быть одинаковы !", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                var s = DateTime.Parse(startDatePicker.Text);
                if (mode== 0 && DateTime.Compare(DateTime.Parse(startDatePicker.Text), DateTime.Parse(endDatePicker.Text)) > 0)
                {
                    MessageBox.Show("Начальная дата не может быть больше конечной даты периода !", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                PrintLogReadViewModel prLogVM = new PrintLogReadViewModel();
                    
                if (mode == 1)  prLogVM.GetStaticticGroup(startDatePicker.Text, endDatePicker.Text);
                else if (mode == 2)  prLogVM.GetStaticticGroupUser(startDatePicker.Text, endDatePicker.Text);
                else if (mode == 3)  prLogVM.GetStaticticGroupUserDep(startDatePicker.Text, endDatePicker.Text);
                else if (mode == 4)  prLogVM.GetStatictAdditionally(startDatePicker.Text, endDatePicker.Text, 4);
                else if (mode == 5)  prLogVM.GetStatictAdditionally(startDatePicker.Text, endDatePicker.Text, 5);
                else if (mode == 6)  prLogVM.GetStatictAdditionally(startDatePicker.Text, endDatePicker.Text, 6);
                else prLogVM.GetStaticticDate(startDatePicker.Text, endDatePicker.Text);

                ItemsView = CollectionViewSource.GetDefaultView(prLogVM.PrLogMV);

                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.ItemsSource = ItemsView;
                ItemsView.Refresh();
                DisplayStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }

        }

        /// <summary>
        /// Выгрузка в exsel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Click_btnExc(object sender, RoutedEventArgs e)
        {
            try
            {
                List<PrLog> iTemDtGr = ItemsView.Cast<PrLog>().ToList();
                #region формирование EXcel
                using (XLWorkbook workbook = new XLWorkbook())
                {
                    Mouse.OverrideCursor = Cursors.Wait;
                    var worksheet = workbook.Worksheets.Add("Статистика сервера печати");
                    worksheet.Row(1).Height = 18;
                    worksheet.Row(1).Style.Font.FontColor = XLColor.White;
                    worksheet.Row(1).Style.Font.Bold = true;
                    if (mode == 1)
                    {
                        worksheet.Cell(1, 1).Value = "Принтер";
                        worksheet.Cell(1, 2).Value = "Подразделение";
                        worksheet.Cell(1, 3).Value = "Кл-во стр.";
                        for (int j = 1; j < 4; j++) worksheet.Cell(1, j).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        int row = 2, col = 0;
                        foreach (PrLog item in iTemDtGr)
                        {
                            worksheet.Cell(row, ++col).Value = item.Printer;
                            worksheet.Cell(row, ++col).Value = item.Departement;
                            worksheet.Cell(row, ++col).Value = item.Countpages;
                            row++;
                            col = 0;
                        }
                    }
                    else if (mode == 2)
                    {
                        worksheet.Cell(1, 1).Value = "Принтер";
                        worksheet.Cell(1, 2).Value = "Сотрудник";
                        worksheet.Cell(1, 3).Value = "Кл-во стр.";
                        for (int j = 1; j < 4; j++) worksheet.Cell(1, j).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        int row = 2, col = 0;
                        foreach (PrLog item in iTemDtGr)
                        {
                            worksheet.Cell(row, ++col).Value = item.Printer;
                            worksheet.Cell(row, ++col).Value = item.Userlog;
                            worksheet.Cell(row, ++col).Value = item.Countpages;
                            row++;
                            col = 0;
                        }
                    }
                    else if(mode == 3)
                    {
                        worksheet.Cell(1, 1).Value = "Принтер";
                        worksheet.Cell(1, 2).Value = "Сотрудник";
                        worksheet.Cell(1, 3).Value = "Подразделение";
                        worksheet.Cell(1, 4).Value = "Кл-во стр.";
                        for(int j=1;j<5;j++) worksheet.Cell(1, j).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        int row = 2, col = 0;
                        foreach (PrLog item in iTemDtGr)
                        {
                            worksheet.Cell(row, ++col).Value = item.Printer;
                            worksheet.Cell(row, ++col).Value = item.Userlog;
                            worksheet.Cell(row, ++col).Value = item.Departement;
                            worksheet.Cell(row, ++col).Value = item.Countpages;
                            row++;
                            col = 0;
                        }
                    }else if (mode == 4)
                    {
                        worksheet.Cell(1, 1).Value = "Принтер";
                        worksheet.Cell(1, 2).Value = "Кл-во стр.";
                        worksheet.Cell(1, 1).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        worksheet.Cell(1, 2).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        int row = 2, col = 0;
                        foreach (PrLog item in iTemDtGr)
                        {
                            worksheet.Cell(row, ++col).Value = item.Printer;
                            worksheet.Cell(row, ++col).Value = item.Countpages;
                            row++;
                            col = 0;
                        }
                    }else if (mode == 5)
                    {
                        worksheet.Cell(1, 1).Value = "Подразделение";
                        worksheet.Cell(1, 2).Value = "Кл-во стр.";
                        worksheet.Cell(1, 1).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        worksheet.Cell(1, 2).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        int row = 2, col = 0;
                        foreach (PrLog item in iTemDtGr)
                        {
                            worksheet.Cell(row, ++col).Value = item.Departement;
                            worksheet.Cell(row, ++col).Value = item.Countpages;
                            row++;
                            col = 0;
                        }
                    }else if (mode == 6)
                    {
                        worksheet.Cell(1, 1).Value = "Пользователь";
                        worksheet.Cell(1, 2).Value = "Кл-во стр.";
                        worksheet.Cell(1, 1).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        worksheet.Cell(1, 2).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        int row = 2, col = 0;
                        foreach (PrLog item in iTemDtGr)
                        {
                            worksheet.Cell(row, ++col).Value = item.Userlog;
                            worksheet.Cell(row, ++col).Value = item.Countpages;
                            row++;
                            col = 0;
                        }
                    }else
                    {
                        worksheet.Cell(1, 1).Value = "ID";
                        worksheet.Cell(1, 2).Value = "Дата";
                        worksheet.Cell(1, 3).Value = "Пользователь";
                        worksheet.Cell(1, 4).Value = "Кл-во стр.";
                        worksheet.Cell(1, 5).Value = "Подразделение";
                        worksheet.Cell(1, 6).Value = "Компьютер";
                        worksheet.Cell(1, 7).Value = "Принтер";
                        worksheet.Cell(1, 8).Value = "Лог принтера печати";
                        for(int j=1;j<9;j++) worksheet.Cell(1, j).Style.Fill.BackgroundColor = XLColor.FromHtml("#9acd32");
                        int row = 2, col = 0;
                        foreach (PrLog item in iTemDtGr)
                        {
                            worksheet.Cell(row, ++col).Value = item.Id;
                            worksheet.Cell(row, ++col).Value = item.Timecreated2;
                            worksheet.Cell(row, ++col).Value = item.Userlog;
                            worksheet.Cell(row, ++col).Value = item.Countpages;
                            worksheet.Cell(row, ++col).Value = item.Departement;
                            worksheet.Cell(row, ++col).Value = item.Compdomen;
                            worksheet.Cell(row, ++col).Value = item.Printer;
                            worksheet.Cell(row, ++col).Value = item.Messagelog;
                            row++;
                            col = 0;
                        }
                    }
                    worksheet.Columns().AdjustToContents();
                    worksheet.Cells().Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;

                    string nmFile = "Статистика сервера печати " + DateTime.Now.ToString("HH.mm.ss");
                    #endregion завершение записи в Excel

                    #region old code
                    /* 
                     //путь к папке мои документы текущего пользователя
                     string md = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                     if (Directory.Exists(md + "\\ReportExсel") == false)
                     {
                        Directory.CreateDirectory(md + "\\ReportExсel");
                     }
                     string pathFile = $"{md}\\ReportExсel\\{nameFile}.xlsx";
                    */
                    #endregion

                    SaveFileDialog svDlg = new SaveFileDialog();
                    svDlg.Filter = "Excel files (.xlsx)|*.xlsx";
                    svDlg.Title = "Сохранить как Excel File";
                    svDlg.FileName = nmFile;

                    if (svDlg.ShowDialog() == true)
                    {
                        Mouse.OverrideCursor = Cursors.Wait;
                        if (!String.IsNullOrEmpty(svDlg.FileName))
                        {
                            workbook.SaveAs(svDlg.FileName);
                            MessageBox.Show($"Excel сформирован и выгружен: {svDlg.FileName}", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }

        }

        private void Click_menuExit(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        /// <summary>
        /// Обновить
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Click_menuRefresh2(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                Click_btnReset(sender, e);
                mode = 0;
                startDatePicker.SelectedDate = null;
                endDatePicker.SelectedDate = null;
                startDatePicker.Text = string.Empty;
                endDatePicker.Text = string.Empty;
                PrintLogReadViewModel prLogVM = new PrintLogReadViewModel();
                prLogVM.GetStatictic(0);
                ItemsView = CollectionViewSource.GetDefaultView(prLogVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.ItemsSource = ItemsView;
                ItemsView.Refresh();
                DisplayStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        /// <summary>
        /// Получить все данные
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Click_menuGetAll(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                Click_btnReset(sender, e);
                startDatePicker.SelectedDate = null;
                endDatePicker.SelectedDate = null;
                startDatePicker.Text = string.Empty;
                endDatePicker.Text = string.Empty;
                PrintLogReadViewModel prLogVM = new PrintLogReadViewModel();
                prLogVM.GetStatictic(1);
                mode = 0;
                ItemsView = CollectionViewSource.GetDefaultView(prLogVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.ItemsSource = ItemsView;
                ItemsView.Refresh();
                this.dtg_printlog.Columns[0].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Visible;
                //this.dtg_printlog.Columns[8].Visibility = Visibility.Visible;
                DisplayStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }


        /// <summary>
        /// Отображение статистики
        /// </summary>
        private void DisplayStatistics()
        {
            this.txt_pagecount.Text = Sum(this.dtg_printlog);
            this.txt_depcount.Text = CntDp(this.dtg_printlog);
            this.txt_printcount.Text = CntPrn(this.dtg_printlog);
            this.txt_usercount.Text = CntUsr(this.dtg_printlog);
            this.txt_compcount.Text = CntDomName(this.dtg_printlog);
        }

        /// <summary>
        /// Получение данных с групирвкой
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Click_menuGroupDep(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                Click_btnReset(sender, e);
                PrintLogReadViewModel prLogDepVM = new PrintLogReadViewModel();
                prLogDepVM.GetStaticticGroup(startDatePicker.Text, endDatePicker.Text);
                mode = 1;
                ItemsView = CollectionViewSource.GetDefaultView(prLogDepVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.Columns[0].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Hidden;
               // this.dtg_printlog.Columns[8].Visibility = Visibility.Hidden;
                this.dtg_printlog.ItemsSource = ItemsView;
                DisplayStatistics();
                //menuRefresh2.Visibility = Visibility.Hidden;
                ItemsView.Refresh();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        /// <summary>
        /// Вернуться на стартовую страницу
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Click_menuHome(object sender, RoutedEventArgs e)
        {
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                Click_btnReset(sender, e);
                startDatePicker.SelectedDate = null;
                endDatePicker.SelectedDate = null;
                startDatePicker.Text = string.Empty;
                endDatePicker.Text = string.Empty;
                PrintLogReadViewModel prLogVM = new PrintLogReadViewModel();
                prLogVM.GetStatictic(0);
                mode = 0;
                ItemsView = CollectionViewSource.GetDefaultView(prLogVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.ItemsSource = ItemsView;
                this.dtg_printlog.Columns[0].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Visible;
                //this.dtg_printlog.Columns[8].Visibility = Visibility.Visible;
                //menuRefresh2.Visibility = Visibility.Visible;
                DisplayStatistics();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        /// <summary>
        /// Получение данных с группировкой по пользователю
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Click_menuGroupUser(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;

            try
            {
                Click_btnReset(sender, e);
                PrintLogReadViewModel prLogDepVM = new PrintLogReadViewModel();
                prLogDepVM.GetStaticticGroupUser(startDatePicker.Text, endDatePicker.Text);
                mode = 2;
                ItemsView = CollectionViewSource.GetDefaultView(prLogDepVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.Columns[0].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Hidden;
                this.dtg_printlog.ItemsSource = ItemsView;
                DisplayStatistics();
                ItemsView.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        private void Click_menuGroupUserDep(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                Click_btnReset(sender, e);
                PrintLogReadViewModel prLogDepVM = new PrintLogReadViewModel();
                prLogDepVM.GetStaticticGroupUserDep(startDatePicker.Text, endDatePicker.Text);
                mode = 3;
                ItemsView = CollectionViewSource.GetDefaultView(prLogDepVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.Columns[0].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Hidden;
                this.dtg_printlog.ItemsSource = ItemsView;
                DisplayStatistics();
                ItemsView.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
           Dispatcher.BeginInvoke(new Action(() =>
            {
                PrintLogReadViewModel prLogVM = new PrintLogReadViewModel();
                prLogVM.GetStatictic(0);
                ItemsView = CollectionViewSource.GetDefaultView(prLogVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));
                this.dtg_printlog.ItemsSource = ItemsView;
                DisplayStatistics();

            }));

            
        }

        private void Loaded_DataGrid(object sender, RoutedEventArgs e)
        {

        }

        private void Click_menuGroupUser2(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                Click_btnReset(sender, e);
                PrintLogReadViewModel prLogDepVM = new PrintLogReadViewModel();
                mode = 6;
                prLogDepVM.GetStatictAdditionally(startDatePicker.Text, endDatePicker.Text, mode);

                ItemsView = CollectionViewSource.GetDefaultView(prLogDepVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));

                this.dtg_printlog.Columns[0].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Hidden;
                this.dtg_printlog.ItemsSource = ItemsView;
                DisplayStatistics();
                ItemsView.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        private void Click_menuGroupDep2(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                Click_btnReset(sender, e);
                PrintLogReadViewModel prLogDepVM = new PrintLogReadViewModel();
                mode = 5;
                prLogDepVM.GetStatictAdditionally(startDatePicker.Text, endDatePicker.Text, mode);

                ItemsView = CollectionViewSource.GetDefaultView(prLogDepVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));

                this.dtg_printlog.Columns[0].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Hidden;
                this.dtg_printlog.ItemsSource = ItemsView;
                DisplayStatistics();
                ItemsView.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }

        private void Click_menuGroupPrn2(object sender, RoutedEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                Click_btnReset(sender, e);
                PrintLogReadViewModel prLogDepVM = new PrintLogReadViewModel();
                mode = 4;
                prLogDepVM.GetStatictAdditionally(startDatePicker.Text, endDatePicker.Text, mode);
                
                ItemsView = CollectionViewSource.GetDefaultView(prLogDepVM.PrLogMV);
                ItemsView.Filter = new Predicate<object>(o => Filter(o as PrLog, Search, mode));

                this.dtg_printlog.Columns[0].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[1].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[2].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[3].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[4].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[5].Visibility = Visibility.Hidden;
                this.dtg_printlog.Columns[6].Visibility = Visibility.Visible;
                this.dtg_printlog.Columns[7].Visibility = Visibility.Hidden;
                this.dtg_printlog.ItemsSource = ItemsView;
                DisplayStatistics();
                ItemsView.Refresh();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        }
    }
}
